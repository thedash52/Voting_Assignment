﻿namespace votingBackend
{
    public class votingBackendConsts
    {
        public const string LocalizationSourceName = "votingBackend";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}